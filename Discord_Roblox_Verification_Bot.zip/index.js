const bot = require('./src/bot');
const server = require('./src/server');

bot.start();
server.start();
